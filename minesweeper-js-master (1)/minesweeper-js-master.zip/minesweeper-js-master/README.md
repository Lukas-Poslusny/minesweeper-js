# minesweeper-js
Homework template for my students

Lukáš Poslušný, Lukáš Kunert
