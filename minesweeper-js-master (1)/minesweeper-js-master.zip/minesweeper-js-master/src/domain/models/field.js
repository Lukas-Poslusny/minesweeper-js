export const field = Object.freeze({
    hidden: 0,
    visible: 1,
    flag: 2,
    question_mark: 3
});
